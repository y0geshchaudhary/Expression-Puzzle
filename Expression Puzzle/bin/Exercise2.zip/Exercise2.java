public class Exercise2 {

	public static final int INFINITY = 1000000;

	public static void main(String[] args) {

		Exercise2 dp = new Exercise2();
		// int n=148;
		int n = 11111;
		int[] conc = new int[n + 1];
		int[] mul = new int[n + 1];
		int[] add = new int[n + 1];

		int arr[]={2,9};
		//int arr[] = { 2, 9 };

		conc[0] = Exercise2.INFINITY;
		for (int i = 0; i < arr.length; i++) {
			if(n>arr[i])
			conc[arr[i]] = 1;
		}
		for (int i = 1; i <= n; i++) {
			if (conc[i] != 1)
				conc[i] = -1;
		}

		// mul[0]=Exercise2.INFINITY;
		for (int i = 0; i <= n; i++) {
			mul[i] = -1;
		}

		for (int i = 0; i <= n; i++) {
			add[i] = -1;
		}
		// for(int i=1 ;i<=n;i++){
		// dp.concat(14,arr,arr.length,conc);
		//System.out.println(dp.mul(n, arr, arr.length, conc,mul));
		System.out.println(dp.add(n,arr, arr.length, conc, mul,add));

		/*
		 * System.out.println(dp.concat(148,arr,arr.length,conc));
		 * System.out.println(dp.concat(1,arr,arr.length,conc));
		 * System.out.println(dp.concat(17,arr,arr.length,conc));
		 * System.out.println(dp.concat(147,arr,arr.length,conc));
		 */
		// }

		System.out.println("hello");

	}

	int concat(int n, int arr[], int arr_size, int conc[]) {

		/*
		 * for(int i=0;i<3;i++){ cout<< arr[i]; }
		 */
		/*
		 * for (int i = 0; i < arr.length; i++) { if(n==arr[i]){ conc[arr[i]]=1;
		 * return conc[n]; } }
		 */

		if (conc[n] != -1) {
			return conc[n];
		} else {
			/*
			 * for(int j=0; j<n;j++){ int current_val=conc[n]; if(conc[j] == -1)
			 * for(int i=0;i<arr_size;i++){ if(n%10==arr[i]){
			 * conc[n]=concat(n/10,arr,arr_size,conc) +
			 * concat(n%10,arr,arr_size,conc); break; } else{ conc[n]=1000; } }
			 * }
			 */
			int minValue = Exercise2.INFINITY, temp;
			for(int j =1;j<=n;j++){
				if(conc[j]>-1 && conc[j]<Exercise2.INFINITY)
					continue;
				else{
					temp=Exercise2.INFINITY;
					minValue=Exercise2.INFINITY;
					for (int i = 0; i < arr_size; i++) {
						
						// if(conc[i]>-1 && conc[i]<Exercise2.INFINITY){
						if (j % 10 == arr[i] || j / 10 == arr[i]) {
							temp = concat(j / 10, arr, arr_size, conc) + concat(j % 10, arr, arr_size, conc);
							if (temp > -1 && temp < minValue)
								minValue = temp;
						} /*
							 * else { if (!(conc[n] < -1 && conc[n] <
							 * Exercise2.INFINITY)) conc[n] = Exercise2.INFINITY; }
							 */
					}
					
					conc[j]=minValue;
				}
			}
			
			// }
			//conc[n] = minValue;
		}
		return conc[n];
	}

	int mul(int n, int arr[], int arr_size, int conc[], int mul[]) {

		//int[] min = new int[mul.length];
		int concatValue = concat(n, arr, arr_size, conc);
		if (concatValue < Exercise2.INFINITY && concatValue > -1) {
			// mul[n]=concatValue;
			return concatValue;
		}

		else if (mul[n] != -1)
			return mul[n];

		else {
			
			 /*int temp = 0, a, b; 
			 for (int i = arr_size - 1; i >= 0; --i) {
				 if (n % arr[i] == 0 && (arr[i] != 0 || arr[i] != 1)){
					 a = n /arr[i]; 
					 b = arr[i]; 
					 temp = mul(a, arr, arr.length, conc, mul) + mul(b, arr, arr.length, conc, mul) + 1; 
					 if (temp > -1 && temp < Exercise2.INFINITY){
						 mul[n] = temp; 
						 break; 
					}
			 
			 }
			 
			 else { 
				 if (!(mul[n] > -1 && mul[n] < Exercise2.INFINITY)) 
					 mul[n] = Exercise2.INFINITY;
				 }
			 
			 }*/
			 

			// modified//
			int minValue = Exercise2.INFINITY, temp = Exercise2.INFINITY, a, b;
			for (int i = 2; i<n; i++) {
				temp = Exercise2.INFINITY;
				if (conc[i] > -1 && conc[i] < Exercise2.INFINITY) {
					if (n%i == 0) {
						a = n / i;
						b = i;
						temp = mul(a, arr, arr.length, conc, mul) + mul(b, arr, arr.length, conc, mul) + 1;
						if (temp > -1 && temp < Exercise2.INFINITY) {
							minValue = temp;
						}
					}
			}
		}
			mul[n]=minValue;
		
		// modified//

		}return mul[n];

	}

	int add(int n, int arr[], int arr_size, int conc[], int mul[], int add[]) {
		int[] min = new int[arr_size];

		int mulValue = mul(n, arr, arr_size, conc, mul);
		if (mulValue < Exercise2.INFINITY && mulValue > -1) {
			// mul[n]=concatValue;
			return mulValue;
		}

		else if (add[n] != -1)
			return add[n];

		else {
			/*int temp = 0;
			for (int i = arr_size - 1; i >= 0; --i) {
				if (arr[i] != 0 && n - arr[i] > 0) {
					temp = add(n - arr[i], arr, arr_size, conc, mul, add) + add(arr[i], arr, arr_size, conc, mul, add)
							+ 1;
					min[i] = temp;
				} else
					min[i] = Exercise2.INFINITY;
			}
			temp = min[0];
			for (int i = 1; i < arr_size; i++) {
				if (min[i] < temp)
					temp = min[i];
			}

			add[n] = temp;*/
			
			// modified//
						int minValue = Exercise2.INFINITY, temp = Exercise2.INFINITY, a, b;
						for (int i = 1; i<n; i++) {
							temp = Exercise2.INFINITY;
							if (conc[i] > -1 && conc[i] < Exercise2.INFINITY) {
								if (n-i>0) {
									temp = add(n - i, arr, arr_size, conc, mul, add) + add(i, arr, arr_size, conc, mul, add) + 1;
									if (temp > -1 && temp < Exercise2.INFINITY) {
										minValue = temp;
									}
								}
							}
						}
						for (int i = 1; i<n; i++) {
							temp = Exercise2.INFINITY;
							if (mul[i] > -1 && mul[i] < Exercise2.INFINITY) {
								if (n-i>0) {
									temp = add(n - i, arr, arr_size, conc, mul, add) + add(i, arr, arr_size, conc, mul, add) + 1;
									if (temp > -1 && temp < Exercise2.INFINITY && minValue>temp) {
										minValue = temp;
									}
								}
						}
					}
					add[n]=minValue;
					
					// modified//

		}
		return add[n];
	}
}
